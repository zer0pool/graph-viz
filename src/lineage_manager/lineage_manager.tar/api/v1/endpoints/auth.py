import logging
from typing import Optional

from dependency_injector.wiring import Provide, inject
from fastapi import APIRouter, Depends, Form, HTTPException
from pydantic import BaseModel

from lineage_manager.core.auth import (
    AuthenticationError,
    OIDCProviderClient,
    AuthenticationError,
    OIDCProviderClient,
)
from lineage_manager.core.config import get_settings
from lineage_manager.core.container import GraphContainer
from lineage_manager.services.user_service import UserService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


class AuthCodePayload(BaseModel):
    code: Optional[str] = None
    id_token: Optional[str] = None
    code_verifier: Optional[str] = None


@router.get("/config")
@inject
def get_auth_config(
    oidc_client: OIDCProviderClient = Depends(Provide[GraphContainer.core.oidc_provider]),
):
    """
    Return minimal configuration so the frontend knows how to initiate OIDC login.
    """
    try:
        config = oidc_client.auth_config()
    except AuthenticationError as exc:
        logger.error("Failed to load auth config: %s", exc)
        raise HTTPException(
            status_code=503, detail="OIDC metadata unavailable"
        ) from exc

    require_signin = get_settings().require_signin
    config["require_signin"] = require_signin
    logger.debug(
        "Auth config requested (issuer=%s, require_signin=%s)",
        config.get("issuer"),
        require_signin,
    )
    return config


@router.post("/exchange")
@inject
def exchange_authorization_code(
    code: Optional[str] = Form(None),
    id_token: Optional[str] = Form(None),
    code_verifier: Optional[str] = Form(None),
    oidc_client: OIDCProviderClient = Depends(Provide[GraphContainer.core.oidc_provider]),
    user_service: UserService = Depends(Provide[GraphContainer.user.user_service]),
):
    """
    Exchange an authorization code for tokens via the configured OIDC provider,
    or verify an ID token directly if provided.
    """
    # Create payload from form data
    payload = AuthCodePayload(code=code, id_token=id_token, code_verifier=code_verifier)

    # If ID token is provided directly, verify it without exchanging code
    if payload.id_token:
        try:
            claims = oidc_client.verify_id_token(payload.id_token)
        except AuthenticationError as exc:
            logger.warning("ID token verification failed: %s", exc)
            raise HTTPException(
                status_code=400, detail=f"Failed to verify ID token: {exc}"
            )

        user_payload = user_service.record_login(claims)

        logger.info(
            "User '%s' authenticated successfully with ID token",
            user_payload.get("sub"),
        )

        return {
            "access_token": None,
            "id_token": payload.id_token,
            "token_type": "Bearer",
            "expires_in": None,
            "refresh_token": None,
            "scope": None,
            "user": user_payload,
        }

    # Otherwise, exchange authorization code for tokens
    try:
        # Clean the code and verifier to remove any potential whitespace issues
        if payload.code:
            payload.code = payload.code.strip()
        if payload.code_verifier:
            payload.code_verifier = payload.code_verifier.strip()

        token_response = oidc_client.exchange_code(payload.code, payload.code_verifier)
    except AuthenticationError as exc:
        logger.warning("Authorization code exchange failed: %s", exc)
        raise HTTPException(status_code=400, detail=str(exc))

    id_token = token_response.get("id_token")

    try:
        claims = oidc_client.verify_id_token(id_token)
    except AuthenticationError as exc:
        logger.warning("ID token verification failed: %s", exc)
        raise HTTPException(status_code=400, detail=f"Failed to verify ID token: {exc}")

    user_payload = user_service.record_login(claims)

    logger.info(
        "User '%s' exchanged authorization code successfully", user_payload.get("sub")
    )

    return {
        "access_token": token_response.get("access_token"),
        "id_token": id_token,
        "token_type": token_response.get("token_type", "Bearer"),
        "expires_in": token_response.get("expires_in"),
        "refresh_token": token_response.get("refresh_token"),
        "scope": token_response.get("scope"),
        "user": user_payload,
    }



@router.post("/authorized")
@inject
def handle_authorized_callback(
    id_token: str = Form(...),
    nonce: Optional[str] = Form(None),
    oidc_client: OIDCProviderClient = Depends(
        Provide[GraphContainer.core.oidc_provider]
    ),
    user_service: UserService = Depends(Provide[GraphContainer.user.user_service]),
):
    """
    Handle the authorized callback from the OIDC provider.
    This endpoint is used when the OIDC provider sends the ID token directly in a POST request.
    """
    logger.info("Received authorized callback with ID token")

    try:
        # Verify the ID token with nonce if provided
        claims = oidc_client.verify_id_token(id_token)
        logger.debug("ID token claims: %s", list(claims.keys()) if claims else None)
        logger.debug("User subject (sub): %s", claims.get("sub") if claims else None)
        logger.debug("Token issuer: %s", claims.get("iss") if claims else None)
        logger.debug("Token audience: %s", claims.get("aud") if claims else None)
        if nonce:
            logger.debug("Nonce verified successfully")
    except AuthenticationError as exc:
        logger.warning("ID token verification failed: %s", exc)
        raise HTTPException(status_code=400, detail=f"Failed to verify ID token: {exc}")

    # Record the user login
    user_payload = user_service.record_login(claims)

    logger.info(f"claims {claims}..")

    logger.info(
        "User '%s' authenticated successfully via authorized callback",
        user_payload.get("sub"),
    )

    # Return the user information and token
    return {
        "access_token": None,
        "id_token": id_token,
        "token_type": "Bearer",
        "expires_in": None,
        "refresh_token": None,
        "scope": None,
        "user": user_payload,
    }