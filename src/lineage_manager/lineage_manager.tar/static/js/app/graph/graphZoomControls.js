/**
 * GraphZoomControls - Zoom and minimap controls
 * Handles zoom in/out, reset, minimap toggle
 */

import { SELECTORS } from "../config.js";

const MINIMAP_SELECTOR = "#cytoscape-minimap";
const MINIMAP_ZOOM_FACTOR = 0.15;

export class GraphZoomControls {
    constructor(graphView) {
        this.view = graphView;
        this.minimapVisible = false;
        this.minimapEl = null;
        this.minimapToggle = null;
    }

    /**
     * Setup zoom controls
     */
    bindControls() {
        const cy = this.view.getCy();
        if (!cy) return;

        const zoomIn = document.querySelector(SELECTORS.zoomControls.in);
        const zoomOut = document.querySelector(SELECTORS.zoomControls.out);
        const reset = document.querySelector(SELECTORS.zoomControls.reset);
        const zoomReset = document.querySelector(SELECTORS.zoomControls.zoomReset);
        const minimap = document.querySelector(SELECTORS.zoomControls.minimap);

        const updateZoomDisplay = () => {
            const label = document.getElementById("zoom-level");
            if (label && cy) {
                label.textContent = `${Math.round(cy.zoom() * 100)}%`;
            }
        };

        this.zoomInHandler = (e) => {
            e.preventDefault();
            const target = Math.min(cy.zoom() * 1.2, cy.maxZoom());
            cy.zoom(target);
            cy.center();
            updateZoomDisplay();
        };

        this.zoomOutHandler = (e) => {
            e.preventDefault();
            const target = Math.max(cy.zoom() * 0.8, cy.minZoom());
            cy.zoom(target);
            cy.center();
            updateZoomDisplay();
        };

        this.resetHandler = (e) => {
            e.preventDefault();
            cy.fit();
            cy.center();
            updateZoomDisplay();
        };

        this.zoomResetHandler = (e) => {
            e.preventDefault();
            cy.zoom(1.0);
            cy.center();
            updateZoomDisplay();
        };

        this.minimapHandler = (e) => {
            e.preventDefault();
            console.info("[Minimap] Toggle button clicked");
            this.toggleMinimap();
        };

        zoomIn?.addEventListener("click", this.zoomInHandler);
        zoomOut?.addEventListener("click", this.zoomOutHandler);
        reset?.addEventListener("click", this.resetHandler);
        zoomReset?.addEventListener("click", this.zoomResetHandler);
        minimap?.addEventListener("click", this.minimapHandler);

        this.minimapToggle = minimap;
        this.updateMinimapToggleState();

        cy.on("zoom", updateZoomDisplay);
        updateZoomDisplay();

        // Store references for cleanup
        this.domElements = { zoomIn, zoomOut, reset, zoomReset, minimap };
    }

    /**
     * Unbind all controls
     */
    unbindControls() {
        const { zoomIn, zoomOut, reset, zoomReset, minimap } = this.domElements || {};

        if (this.zoomInHandler) zoomIn?.removeEventListener("click", this.zoomInHandler);
        if (this.zoomOutHandler) zoomOut?.removeEventListener("click", this.zoomOutHandler);
        if (this.resetHandler) reset?.removeEventListener("click", this.resetHandler);
        if (this.zoomResetHandler) zoomReset?.removeEventListener("click", this.zoomResetHandler);
        if (this.minimapHandler) minimap?.removeEventListener("click", this.minimapHandler);

        this.minimapVisible = false;
        this.cleanupMinimapElements();
    }

    /**
     * Toggle minimap visibility
     */
    toggleMinimap() {
        console.info("[Minimap] toggleMinimap invoked. Current state:", this.minimapVisible);
        this.setMinimapVisible(!this.minimapVisible);
    }

    /**
     * Set minimap visibility
     */
    setMinimapVisible(visible) {
        this.minimapVisible = Boolean(visible);
        const mm = this.getMinimapElement();
        console.info("[Minimap] setMinimapVisible ->", this.minimapVisible, "element?", Boolean(mm));
        if (mm) {
            mm.style.display = this.minimapVisible ? "block" : "none";
        } else {
            // Element might not be ready yet; retry shortly
            requestAnimationFrame(() => {
                const retry = this.getMinimapElement();
                if (retry) {
                    retry.style.display = this.minimapVisible ? "block" : "none";
                }
            });
        }
        this.updateMinimapToggleState();
    }

    /**
     * Get minimap element
     */
    getMinimapElement() {
        if (typeof document === "undefined") return null;

        if (this.minimapEl && document.body.contains(this.minimapEl)) {
            console.debug("[Minimap] Reusing cached minimap element");
            return this.minimapEl;
        }

        this.minimapEl = document.querySelector(MINIMAP_SELECTOR);
        if (this.minimapEl) {
            console.debug("[Minimap] Captured minimap element");
        }
        return this.minimapEl;
    }

    /**
     * Remove existing minimap instances
     */
    cleanupMinimapElements() {
        if (typeof document === "undefined") return;
        document.querySelectorAll(MINIMAP_SELECTOR).forEach((el) => el.remove());
        this.minimapEl = null;
    }

    /**
     * Setup minimap
     */
    setupMinimap() {
        const cy = this.view.getCy();
        if (!cy) return;

        // Remove orphaned minimap DOMs from previous renders
        this.cleanupMinimapElements();

        console.info("[Minimap] Initializing Cytoscape minimap (zoomFactor:", MINIMAP_ZOOM_FACTOR, ")");
        cy.minimap({ zoomFactor: MINIMAP_ZOOM_FACTOR });

        this.captureMinimapElement();
    }

    captureMinimapElement(attempt = 0) {
        const MAX_ATTEMPTS = 10;
        const shell = document.getElementById("graph-shell");
        const node = document.querySelector(MINIMAP_SELECTOR);

        if (node) {
            if (shell && node.parentElement !== shell) {
                shell.appendChild(node);
                console.debug("[Minimap] Reattached minimap to #graph-shell");
            }
            this.styleMinimap(node);
            this.minimapEl = node;
            node.style.display = this.minimapVisible ? "block" : "none";
            console.info("[Minimap] Minimap element ready.");
            return;
        }

        if (attempt >= MAX_ATTEMPTS) {
            console.warn("[Minimap] Failed to capture minimap element after retries.");
            return;
        }
        requestAnimationFrame(() => this.captureMinimapElement(attempt + 1));
    }

    styleMinimap(node) {
        if (!node) return;
        node.style.position = "absolute";
        node.style.bottom = "20px";
        node.style.right = "20px";
        node.style.left = "auto";
        node.style.top = "auto";
        node.style.width = "220px";
        node.style.height = "140px";
        node.style.background = "rgba(255, 255, 255, 0.92)";
        node.style.border = "1px solid rgba(26, 115, 232, 0.7)";
        node.style.borderRadius = "10px";
        node.style.padding = "8px";
        node.style.boxShadow = "0 12px 32px rgba(15, 23, 42, 0.18)";
        node.style.pointerEvents = "auto";
        node.style.zIndex = "40";
    }

    updateMinimapToggleState() {
        if (!this.minimapToggle) return;
        this.minimapToggle.classList.toggle("minimap-active", this.minimapVisible);
        this.minimapToggle.setAttribute("aria-pressed", this.minimapVisible ? "true" : "false");
    }

    /**
     * Is minimap visible
     */
    isMinimapVisible() {
        return this.minimapVisible;
    }
}

export default GraphZoomControls;
